






%sets separations

[trainingSet, validationSet] = splitEachLabel(imds, 0.3, 'randomize');

%----------------------